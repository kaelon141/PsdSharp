# PsdSharp
Cross-platform .NET library for loading, manipulating and rendering PSD (Photoshop native file format) and PSB (Photoshop Large Document Format) files, written entirely in managed C# code.
