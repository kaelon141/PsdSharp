namespace PsdSharp;

public enum ImageCompression
{
    Raw = 0,
    Rle = 1,
    ZipWithoutPrediction = 2,
    ZipWithPrediction = 3,
}