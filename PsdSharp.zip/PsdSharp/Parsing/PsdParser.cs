namespace PsdSharp.Parsing;

internal class PsdParser
{
    private readonly ParseContext _context;

    public PsdParser(ParseContext context)
    {
        _context = context;
    }

    // public PsdFile Parse()
    // {
    //     var header = HeaderParser.Parse(_context);
    //     
    // }
}