namespace PsdSharp;

public enum BorderUnit
{
    Inches = 1,
    Centimeters = 2,
    Points = 3,
    Picas = 4,
    Columns = 5
}