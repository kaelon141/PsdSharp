namespace PsdSharp;

public enum Clipping
{
    Base = 0,
    NonBase = 1
}