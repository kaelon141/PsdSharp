using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PsdSharp.Tests")]